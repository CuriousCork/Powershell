$date = Get-Date -format "yyyy-MM-dd"
Compress-Archive -Path 'C:\Users\diogo\Desktop\Escola\12\app' -CompressionLevel 'Fastest' -DestinationPath ".\backup-$date"
Write-Host "Create backup at $('./backup-' + $date + '.zip')"